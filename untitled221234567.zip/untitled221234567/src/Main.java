// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Reader reader = new Reader("кандыбек",24,"asdf",2345,12345234);
        System.out.println(reader.takeBook(3));
        System.out.println(reader.returnBook(3));

        //--------------------------------------------------------------------------------------------------------------

        Person person1 = new Person(" aa ",12345, " aa ");
        Person person2 = new Person(" aa ",12, " aa ");
        Person person3 = new Person(" aa ",123, " aa ");
        Person person5 = new Person(" aa ",123345, " aa ");
        Person person6 = new Person(" aa ",1, " aa ");
        Person [] person4 = {person1,person2,person3,person5,person6};
        System.out.println(aa(person4));
        System.out.println(gg(person4));
    }
    public static Person aa (Person [] person4 ){
        Person ss = person4 [0];
        for (int i = 0 ; i < person4.length; i++) {
            if  (person4[i].age< ss.age){
                ss = person4 [i];
            }
        }
        return ss;
    }
    public static Person gg (Person [] person4 ){
        Person ss = person4 [0];
        for (int i = 0 ; i < person4.length; i++) {
            if  (person4[i].age> ss.age){
                ss = person4 [i];
            }
        }
        return ss;

        //--------------------------------------------------------------------------------------------------------------

       /* Гул гул1 = new Гул(" роза ", 5, 1500);
        Гул гул2 = new Гул(" кактус ", 3, 150);
        Гул гул3 = new Гул(" роза ", 7, 1700);
        Гул гул4 = new Гул(" рамашка ", 10, 2000);
        Гул гул5 = new Гул(" тюльпан ", 6, 1400);
        Гул[] aa = {гул1, гул2, гул3, гул4, гул5};
        System.out.println(ss(aa));
    }
    public static Гул ss(Гул[] aa) {
        Гул ss = aa[0];
        for (int i = 0; i < aa.length ; i++) {
            if (aa[i].цена > ss.цена ) {
                ss = aa[i];
            }
        }
        return ss;*/

        //--------------------------------------------------------------------------------------------------------------

       /* Season season = new Season();
        Scanner scanner = new Scanner(System.in);
        int ss = season.number(scanner.nextInt());*/

        //--------------------------------------------------------------------------------------------------------------

        /*Scanner scan = new Scanner(System.in);
        Book book1 = new Book("Book1", 25, "Author1");
        Book book2 = new Book("Book2", 2, "Author2");
        Book book3 = new Book("Book3", 22, "Author3");
        Book book4 = new Book("Book4", 26, "Author4");
        Book book5 = new Book("Book5", 14, "Author5");
        Book book6 = new Book("Book6", 16, "Author6");

        Book[] book = {book1, book2, book3, book4, book5};
        Library library = new Library("Library", "Arixama 456", book);


        System.out.println(Arrays.toString(library.removeBook(book2)));

        library.addBook(book6);
        System.out.println(library);

        library.updateBookByName("Book2", 255);
        System.out.println(library);

        library.getAllBooksAuthor("Author1");
        System.out.println(library);*/

    }
}