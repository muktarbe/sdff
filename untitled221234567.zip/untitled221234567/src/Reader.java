public class Reader {
    String fullName;
    int libraryCardNumber;
    String faculty;
    int dateOfBirth;
    int phoneNumber;

    public Reader(String fullName, int libraryCardNumber, String faculty, int dateOfBirth, int phoneNumber) {
        this.fullName = fullName;
        this.libraryCardNumber = libraryCardNumber;
        this.faculty = faculty;
        this.dateOfBirth = dateOfBirth;
        this.phoneNumber = phoneNumber;
    }

    public  String takeBook (int number){
        return  fullName + " взял " + number;

    }
    public String returnBook (int number ){
        return fullName + " вернул "+ number;
    }
}
