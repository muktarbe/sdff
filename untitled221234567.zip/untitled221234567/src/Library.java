import java.util.Arrays;

public class Library {
    private  String name;
    private String addess;
    private Book[] books;

    public Library(String name, String addess, Book[] books) {
        this.name = name;
        this.addess = addess;
        this.books = books;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddess() {
        return addess;
    }

    public void setBooks(Book[] books) {
        this.books = books;
    }

    public Book[] getBooks() {
        return books;
    }

    public void setAddess(String addess) {
        this.addess = addess;
    }




    public Book[] removeBook(Book bookName){
        int indexToRemove = -1;
        for (int i = 0; i < books.length; i++) {
            if (bookName.getName().equals(books[i].getName())) {
                indexToRemove = i;
                break;
            }
        }

        if (indexToRemove != -1) {
            Book[] updatedBooks = new Book[books.length - 1];
            int currentIndex = 0;
            for (int i = 0; i < books.length; i++) {
                if (i != indexToRemove) {
                    updatedBooks[currentIndex] = books[i];
                    currentIndex++;
                }
            }
            books = updatedBooks;
        }

        return books;
    }

    public Book[] updateBookByName(String bookName, int bookNumber){
        for (Book b : books) {
            if(b.getName().equals(bookName)){
                b.setNumber(bookNumber);
                break;
            }
        }
        return books;
    }

    public String addBook(Book bookName) {
        for (Book b : books) {
            if (b.getName().equals(bookName.getName()))
                return "Книга уже есть";
        }
        Book[] books1 = new Book[books.length];
        for (int i = 0; i < books.length; i++) {
            books1[i] = books[i];
        }
        books1[books.length-1]=bookName;
        books = Arrays.copyOf(books1, books1.length);

        return Arrays.toString(books);
    }

    public Book[] getAllBooksAuthor(String author){
        Book[] authorBooks = new Book[books.length+1];
        for (Book book : books) {
            if (book.getAuthor().equals(author)) {
                authorBooks[authorBooks.length - 1] = book;
                books = Arrays.copyOf(authorBooks, authorBooks.length);
            }
        }
        return authorBooks;
    }


    @Override
    public String toString() {
        return "Library" +
                "name: " + name + "\n" +
                "addess: " + addess + "\n" +
                "books: " + Arrays.toString(books);
    }
}